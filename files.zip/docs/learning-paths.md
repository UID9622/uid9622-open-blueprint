# Learning paths (placeholder)
- Starter
- Advanced
- Expert