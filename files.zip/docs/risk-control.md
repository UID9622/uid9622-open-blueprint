# Risk control (placeholder)
Green / Yellow / Red examples and procedures.