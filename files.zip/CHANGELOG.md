## v0.9 (Public Preview)
- Initialize repository structure and legal files
- Add docs and templates placeholders